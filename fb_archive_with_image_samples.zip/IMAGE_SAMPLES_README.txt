Image samples added for the Image Forensics module demo.

Folders:
- profile_photos/
- media/photos/
- messages/inbox/*/photos/

These are synthetic demo images created only to test UI flow and file discovery.
AI detector outputs may vary because they are not real-world forensic samples.
